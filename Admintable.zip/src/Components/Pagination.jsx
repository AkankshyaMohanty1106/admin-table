import React from "react";
import { getTotalNumPages } from "./Functions/pageFun";
import "./Pagination.css"

const Pagination = (props) => {
  const { usersLength, setPage, page, deleteSelected } = props;
  const totalPages = getTotalNumPages(usersLength);
  const changePage = (index) => {
    setPage(index);
  };

  let pages = [];
  for (let i = 1; i <= totalPages; i++) {
    pages.push(
      <div
        key={i}
        onClick={() => changePage(i)}
        className={page === i ? "selected":"page"}
      >
        {i}
      </div>
    );
  }
  return (
    <div style={{width:"600px"}}>
      <div style={{display:"flex",justifyContent:"space-between"}}>
        <button className="delete" onClick={() => deleteSelected()}>Delete Selected</button>
        <div style={{width:"300px"}}>
           <div style={{display:"flex",justifyContent:"space-evenly",cursor:"pointer"}}> {pages}</div>
            </div>
      </div>
    </div>
  );
};

export default Pagination;
