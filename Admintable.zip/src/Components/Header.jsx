import React from 'react'

const Header = () => {
  return (
    <>
    <div style={{background:"#6262d6",color:"white"}}>
        <div style={{display:"flex",justifyContent:"space-between",margin:"0px 10px 0px 10px",height:"50px",alignItems:"center"}}>
        <div>Home</div>
        <div>Login</div>
        </div>
    </div>
    </>
  )
}

export default Header
