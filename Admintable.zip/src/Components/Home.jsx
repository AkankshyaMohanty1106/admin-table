import React, { useState, useEffect, useRef } from "react";
import Header from "./Header";
import axios from "axios";
import Iconmoon from "../IconFiles/icon";
import "./Home.css";
import { searchInUsers } from "./Functions/searchFun";
import { RowIndexIs } from "./Functions/pageFun";
import AdminUsersList from "./AdminUsersList";
import Pagination from "./Pagination";

const Home = () => {
  const [addminData, setAdminData] = useState([]);
  const [rander, setRander] = useState(false);
  const [page, setPage] = useState(1);
  const selectAllCheckRef = useRef(null);
  const index = RowIndexIs(page);
  useEffect(() => {
    axios
      .get(
        "https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json"
      )
      .then((response) => {
        setAdminData(processUsersResponse(response.data));
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const processUsersResponse = (users) => {
    return users.map((user) => {
      user.selected = false;
      user.edit = false;
      user.show = true;
      return user;
    });
  };

  const searchAdmin = (e) => {
    setPage(1);
    let searchValueInLowerCase = e.target.value;
    setAdminData(searchInUsers(searchValueInLowerCase, addminData));
  };
  const selectAllCheckBox = (e) => {
    const listedUserIds = addminData
      .filter((user) => user.show)
      .slice(index, index + 10)
      .map((user) => user.id);

    let tempUsers = addminData.map((user) => {
      if (listedUserIds.includes(user.id)) {
        user.selected = e.target.checked;
        return user;
      }
      return user;
    });

    setAdminData(tempUsers);
    setRander(!rander);
  };
  const deleteSelectedBox = () => {
    if (window.confirm("Selected users will be deleted")) {
      setAdminData((prevState) => prevState.filter((user) => !user.selected));
      selectAllCheckRef.current.checked = false;
    }
  };
  const selectOneBox = (id) => {
    let tempUsers = addminData;
    const index = tempUsers.findIndex((user) => user.id === id);
    tempUsers[index].selected = !tempUsers[index].selected;
    setAdminData(tempUsers);
    setRander((prevState) => !prevState);
  };
  const saveUser = (id, nameRef, emailRef, roleRef) => {
    let tempUsers = addminData;
    const index = tempUsers.findIndex((user) => user.id === id);
    tempUsers[index].name = nameRef.current.value;
    tempUsers[index].email = emailRef.current.value;
    tempUsers[index].role = roleRef.current.value;
    tempUsers[index].edit = false;
    setAdminData(tempUsers);
    setRander((prevState) => !prevState);
  };
  const editAdmin = (id) => {
    let tempUsers = addminData;
    const index = tempUsers.findIndex((user) => user.id === id);
    tempUsers[index].edit = true;
    setAdminData(tempUsers);
    setRander((prevState) => !prevState);
  };
  const deleteAdmin = (id) => {
    let tempUsers = addminData.filter((user) => user.id !== id);
    setAdminData(tempUsers);
    setRander((prevState) => !prevState);
  };
  return (
    <>
      <Header />
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div>
          <input
            className="search-bar"
            type="text"
            placeholder="Search by name, email or role"
            onChange={searchAdmin}
          />
        </div>

        {addminData.length > 0 && (
          <div style={{ margin: "5px 0px 5px 20px" }}>
            <AdminUsersList
              page={page}
              setPage={setPage}
              selectAll={selectAllCheckBox}
              selectAllRef={selectAllCheckRef}
              selectOne={selectOneBox}
              saveUser={saveUser}
              editUser={editAdmin}
              deleteUser={deleteAdmin}
              addminData={addminData
                .filter((user) => user.show)
                .slice(index, index + 10)}
            />
          </div>
        )}
        {addminData.length > 0 && (
          <div style={{ margin: "5px 0px 5px 20px" }}>
            <Pagination
              usersLength={addminData.filter((user) => user.show).length}
              page={page}
              setPage={setPage}
              deleteSelected={deleteSelectedBox}
            />
          </div>
        )}
      </div>
    </>
  );
};

export default Home;
