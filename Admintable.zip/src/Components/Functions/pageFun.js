const config = {}
config.PAGE_SIZE = 10

export const RowIndexIs = (page)=> {
    return (page-1)*config.PAGE_SIZE ;
}
export const getTotalNumPages = (length)=> {
    return Math.ceil(length/10);
}




