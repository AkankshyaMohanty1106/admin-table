import React, { useState, useEffect, useRef } from "react";
import Iconmoon from "../IconFiles/icon";
import Admintable from "./Admintable";

const AdminUsersList = (props) => {
  useEffect(() => {
    if (props.addminData.length === 0 && props.page > 1) {
      props.setPage(props.page - 1);
    }
  }, [props.page, props.setPage, props.addminData.length]);
  let fillRows = [];
  for (
    let i = props.addminData.filter((user) => user.show).length;
    i < 10;
    i++
  ) {
    fillRows.push(<tr key={i}></tr>);
  }
  if (props.addminData.length === 0 && props.page === 1) {
    return <div>NO USERS IN THE SYSTEM</div>;
  }
  return (
    <div>
      <table style={{border:"2px solid black",width:"50%"}}>
        <tr>
          <th>
            <input
              type="checkbox"
              ref={props.selectAllRef}
              onChange={(e) => {
                props.selectAll(e);
              }}
              name="selectAll"
            />
          </th>
          <th style={{float:"left"}}>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Action</th>
        </tr>
        {props.addminData.map((val, key) => {
          return val.show ? (
            <Admintable
              selectOne={props.selectOne}
              saveUser={props.saveUser}
              editUser={props.editUser}
              deleteUser={props.deleteUser}
              key={val.id}
              user={val}
            />
          ) : (
            ""
          );
        })}
        {fillRows}
      </table>
    </div>
  );
};

export default AdminUsersList;
