import React ,{useRef} from 'react';
import Iconmoon from "../IconFiles/icon";

const Admintable = (props) => {
    const { user, deleteUser, editUser, saveUser, selectOne } = props;
    const nameRef = useRef(null);
  const emailRef = useRef(null);
  const roleRef = useRef(null);
  return (
    <tr key={user.id}>
      <td>
        <label for={`check-${user.id}`}>
          <input
            id={`check-${user.id}`}
            type="checkbox"
            data={`${user.selected}`}
            onChange={() => selectOne(user.id)}
            checked={user.selected}
          ></input>
        </label>
      </td>
      <td>
        <input
          readOnly={!user.edit}
          type="text"
          ref={nameRef}
          name="name"
          defaultValue={user.name}
          style={!user.edit ? {border:"none",textOverflow:"ellipsis"} : {}}
        ></input>
      </td>
      <td>
        <input
          readOnly={!user.edit}
          type="email"
          ref={emailRef}
          name="email"
          defaultValue={user.email}
          style={!user.edit ? {border:"none",textOverflow:"ellipsis"} : {}}
        />
      </td>
      <td>
        <input
          readOnly={!user.edit}
          type="text"
          ref={roleRef}
          name="role"
          defaultValue={user.role}
          style={!user.edit ? {border:"none",textOverflow:"ellipsis",marginLeft:"100px"} : {}}
        />
      </td>
      <td style={{cursor:"pointer"}}>
        {user.edit ? (
            <Iconmoon  icon={"view"} color="black" size={18} onClick={() => saveUser(user.id, nameRef, emailRef, roleRef)}/>
          
        ) : (
            <Iconmoon icon={"edit"} size={18} onClick={() => editUser(user.id)}/>
        )}

        <Iconmoon  icon={"delete"} size={18} onClick={() => deleteUser(user.id)}></Iconmoon>
      </td>
    </tr>
  )
}

export default Admintable
