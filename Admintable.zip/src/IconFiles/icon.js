import React from 'react';
import IconMoon from "react-icomoon";
const iconSet = require("./selection.json");

const Iconmoon = ({...props}) => {
  return (
    <IconMoon
    iconSet={iconSet}
    {...props}/>
  )
}

export default Iconmoon
